var
    d,
    ws = new WebSocket("ws://"+window.location.hostname+":9090/"),
    myid = new Date().toString().replace(/[\W]+/g, ""); //goodenough

ws.onmessage = function (e) {
    console.log(e.data);
    var id, q = JSON.parse(e.data);

    d = document.getElementById(q.id);
    if (!d) {
        d=document.createElement("div");
        d.classList.add("out");
        d.setAttribute("id", q.id);
        document.body.appendChild(d);
    }

    d.setAttribute(
        "style",
        "position: absolute; top:"+q.y+"px; left:"+q.x+"px;"
    );

};

document.addEventListener("mousemove",
    function(e) {
        ws.send(
            JSON.stringify(
                {
                    x: e.clientX,
                    y: e.clientY,
                    id: myid
                }
            )
        );
    }
);
